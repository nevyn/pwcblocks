#include <stdio.h>
#include <Block.h>

void intforeach(int *array, unsigned count, void(^callback)(int))
{
	for(unsigned i = 0; i < count; i++)
		callback(array[i]);
}

int main (int argc, const char * argv[]) {
	int numbers[] = {72, 101, 108, 108, 111, 33};
	
	intforeach(numbers, 6, ^ (int number) {
		printf("%c", number);
	});
	printf("\n");
	
	return 0;
}
