#import <Foundation/Foundation.h>

typedef void(^BasicBlock)(void);

@interface LogMessage : NSObject {
	NSString *logLevel;
}
@property (retain) NSString* logLevel;
@end
@implementation LogMessage
@synthesize logLevel;
-(id)init;
{
	self.logLevel = @"Warning";
	return self;
}
-(BasicBlock)printLater:(NSString*)someObject;
{
	return [[^ {
		NSLog(@"%@: %@", 
					logLevel,
					someObject
					);
	} copy] autorelease];
}
-(id)retain;
{
	NSLog(@"The LogMessage was retained");
	return [super retain];
}
@end


int main (int argc, const char * argv[]) {
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	
	LogMessage *lm = [LogMessage new];
	BasicBlock bl = [lm printLater:@"Hello world"];
	lm.logLevel = @"Info";
	
	bl();
	
	[pool drain];
	return 0;
}
