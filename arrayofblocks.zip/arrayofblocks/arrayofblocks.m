#import <Foundation/Foundation.h>

int main (int argc, const char * argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
		
		NSArray *someActions = [NSArray arrayWithObjects:
			[[^ { NSLog(@"Hello");   } copy] autorelease],
			[[^ { NSLog(@"World!");  } copy] autorelease],
			[[^ { NSLog(@"Awesome.");} copy] autorelease],
			nil
		];
		
		for (void(^block)() in someActions) {
			block();
		}
		
    [pool drain];
    return 0;
}
