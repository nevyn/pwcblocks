#import <Foundation/Foundation.h>

typedef int (^BasicBlock)();

@interface VerboseObject : NSObject
{
	int three;
}
@end
@implementation VerboseObject
-(id)init;
{
	NSLog(@"hello %p", self);
	three = 3;
	return self;
}
-(id)retain;
{
	NSLog(@"Retain %p", self);
	return [super retain];
}
-(void)release;
{
  NSLog(@"Release %p", self);
	[super release];
}
-(void)dealloc;
{
	NSLog(@"bye %p", self);
	[super dealloc];
}
-(BasicBlock)weakRef;
{
	__block VerboseObject *blockSelf = self;
	return [[^ {
		return blockSelf->three;
	} copy] autorelease];
}
-(BasicBlock)strongRef;
{
	return [[^ {
		return three;
	} copy] autorelease];
}

@end


int main (int argc, const char * argv[]) {
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

	VerboseObject *vb = [[VerboseObject new] autorelease];
	NSLog(@"Fetching a block weak-ref'ing ivar in vb; should not retain"); 
	BasicBlock a = [vb weakRef];

	NSLog(@"Fetching a block strong-ref'ing ivar in vb; should retain");
	BasicBlock b = [vb strongRef];

	a(); b();
	
	NSLog(@"Draining autorelease pool; vb should be released twice");
	[pool drain];
	return 0;
}
